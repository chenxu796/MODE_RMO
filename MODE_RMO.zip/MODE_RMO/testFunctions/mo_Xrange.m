% MOP: upper and low bound
% SCH FON  POL KUR
% ZDT1 ZDT2 ZDT3 ZDT4 ZDT6 
% DTLZ1  DTLZ2  DTLZ3 DTLZ4 DTLZ5 DTLZ6 
% F1 F2 F3 F4  F5 F6 F7 F8 F9
 
% SCH
if  strcmp(fun,'SCH')
    M=2;   %number of objective
    D=1;  %dimension of problem
    Xmax=2*ones(1,D);
    Xmin=0*ones(1,D);
end

% FON
if  strcmp(fun,'FON') 
    M=2;   %number of objective
    D=3;  %dimension of problem
    Xmax=4*ones(1,D);
    Xmin=-4*ones(1,D);
end

 % POL
if  strcmp(fun,'POL')  
    M=2;   %number of objective
    D=2;  %dimension of problem
    Xmax=pi*ones(1,D);
    Xmin=-pi*ones(1,D);
end

% KUR
if  strcmp(fun,'KUR')  
    M=2;   %number of objective
    D=3;  %dimension of problem
    Xmax=5*ones(1,D);
    Xmin=-5*ones(1,D);
end

% ZDT 1
if strcmp(fun,'ZDT1') 
    M=2;  %number of objective
    D=30;%dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);
end

% ZDT 2
if strcmp(fun,'ZDT2')
    M=2;  %number of objective
    D=30;%dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);
end

% ZDT 3
if strcmp(fun,'ZDT3')
    M=2;  %number of objective
    D=30;%dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);
end

% ZDT 4
if strcmp(fun,'ZDT4')
    M=2;  %number of objective
    D=10;%dimension of problem
    Xmax=[1 5*ones(1,D-1)];
    Xmin=[0 -5*ones(1,D-1)];
end

% ZDT 6
if strcmp(fun,'ZDT6')
    M=2;  %number of objective
    D=10;%dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);
end
 
 %DTLZ1
if  strcmp(fun,'DTLZ1')    
%     M=input('number of objective��M=');
    M=3;
    D=7;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);   
end 


 %DTLZ2
if  strcmp(fun,'DTLZ2') 
  %     M=input('number of objective��M=');
    M=3;
    D=12;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D); 
end 

 %DTLZ3
if  strcmp(fun,'DTLZ3') 
    %     M=input('number of objective��M=');
    M=3; 
    D=12;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);   
end 

 %DTLZ4
if  strcmp(fun,'DTLZ4') 
    %     M=input('number of objective��M=');
    M=3; 
    D=12;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);     
end 
  
  %DTLZ5
if  strcmp(fun,'DTLZ5') 
    M=3;   %number of objective
    D=12;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);    
end

  %DTLZ6
if  strcmp(fun,'DTLZ6') 
    M=3;   %number of objective
    D=12;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);  
end

%DTLZ7
if  strcmp(fun,'DTLZ7') 
    M=3;   %number of objective
    D=22;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);  
end
 
% F1
if  strcmp(fun,'F1') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);  
end

% F2
if  strcmp(fun,'F2') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=[1 1*ones(1,D-1)];
    Xmin=[0 -1*ones(1,D-1)];  
end

% F3
if  strcmp(fun,'F3') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=[1 1*ones(1,D-1)];
    Xmin=[0 -1*ones(1,D-1)];  
end

% F4
if  strcmp(fun,'F4') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=[1 1*ones(1,D-1)];
    Xmin=[0 -1*ones(1,D-1)];  
end

% F5
if  strcmp(fun,'F5') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=[1 1*ones(1,D-1)];
    Xmin=[0 -1*ones(1,D-1)];  
end

% F6
if  strcmp(fun,'F6') 
    M=3;   %number of objective
    D=10;  %dimension of problem
    Xmax=[1 1 1*ones(1,D-2)];
    Xmin=[0 0 -1*ones(1,D-2)];  
end

% F7
if  strcmp(fun,'F7') 
    M=2;   %number of objective
    D=10;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);  
end

% F8
if  strcmp(fun,'F8') 
    M=2;   %number of objective
    D=10;  %dimension of problem
    Xmax=1*ones(1,D);
    Xmin=0*ones(1,D);  
end

% F9
if  strcmp(fun,'F9') 
    M=2;   %number of objective
    D=30;  %dimension of problem
    Xmax=[1  1*ones(1,D-1)];
    Xmin=[0 -1*ones(1,D-1)];  
end