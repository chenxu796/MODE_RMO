% Multi-Objective Differential Evolution with Ranking-Based Mutation Operator and Its Application in Chemical Process Optimization.
% Chemometrics and Intelligent Laboratory Systems (2014).
% Chen, Xu, Wenli Du, and Feng Qian. 

% MODE without Ranking-Based Mutation Operator  
% Written by Chen Xu,  2013.11.20
% Revised 2014.8.22 
% Email: chenxu796@gmail.com

clear all;
clc

format long
 
global Xmax Xmin M D
addpath('testFunctions');
addpath('ParetoFront');


for count=1:1 

tic    
    
rand('state',sum(100*clock))
fun='ZDT1';       % choose problem
PF = load('ZDT1.txt');
mo_Xrange;


% input parameters
F = 0.5;
CR = 0.3;
popSize = 100;
Maxgen =  250;


% 1. Evaluate the initial population P of random individuals.
Range = Xmax-Xmin;
P = repmat(Xmin,popSize,1)+rand(popSize,D).*repmat(Range,popSize,1);
for i = 1:popSize
    fit(i,:) = mo_test_function(P(i,:),fun);
end 

[P,fit,Fnum] = nondSort(P,fit);  % Fast nondominated sorting
[P,fit,cd] = CrowDis(P,fit,Fnum); %  crowding distance 
cd=[]; Fnum=[];
 
% 2. While stopping criterion not met, do:
for gen = 1:Maxgen
    
    %  mutation: DE/rand/1
    for k = 1:popSize
        index = randperm(popSize);
        if index(1)==k  index(1)=index(end); end
        if index(2)==k  index(2)=index(end); end
        if index(3)==k  index(3)=index(end); end 
        Mut(k,:) = P(index(1),:)+F*(P(index(2),:)-P(index(3),:));
    end

    %  Crossover
    for k = 1:popSize 
        sn = randi(D); 
        for i=1:D
            if rand<CR | i==sn
                C(k,i) = Mut(k,i); 
            else
                C(k,i) = P(k,i); 
            end
        end
        % Check bound constraints
        C(k,:) = CheckBound_r(C(k,:),Xmax,Xmin);
    end

    %(b) Evaluate the candidate.
    for k = 1:popSize 
        fit_C(k,:) = mo_test_function(C(k,:),fun);
    end

    % (c)  If the candidate dominates the parent, the candidate replaces the parent.
    %      If the parent dominates the candidate, the candidate is discarded.
    %      Otherwise, the candidate is added in the population.  
    num = popSize+1; 
    for k = 1:popSize 
        if Dominate(fit_C(k,:),fit(k,:))
            fit(k,:) = fit_C(k,:);
            P(k,:) = C(k,:);
        elseif ~Dominate(fit_C(k,:),fit(k,:)) & ~Dominate(fit(k,:),fit_C(k,:))
            fit(num,:) = fit_C(k,:);
            P(num,:) = C(k,:);
            num = num+1; 
        end
    end 
 
    %  2.2. If the population has more than popSize individuals, truncate it.
    [P,fit,Fnum] = nondSort(P,fit);  
    [P,fit,cd] = CrowDis(P,fit,Fnum);
    P = P(1:popSize,:);
    fit = fit(1:popSize,:);
    cd=[]; Fnum=[];

    % calculate the performance metric GD and IGD
    GD(gen,:) = calculateGD(fit,PF);
    IGD(gen,:) = calculateIGD(fit,PF);
    gen 
    [GD(gen,:) IGD(gen,:)]
    % polt the pareto front
    if mod(gen,1 )==0
        if M==2
           plot(fit(:,1),fit(:,2),'o','MarkerSize',5); 
        elseif M==3
           plot3(fit(:,1),fit(:,2),fit(:,3),'o','MarkerSize',5); 
           set(gca,'xdir','reverse'); set(gca,'ydir','reverse');
        end
        title([num2str(gen),'  ' ,num2str(size(P,1))])
        drawnow
    end 

end

time=toc;

count
j=mod(count,10);
i=(count-j)/10;
filename=strcat('MODE_ZDT1_',char(48+i),char(48+j));
save(filename);

end
