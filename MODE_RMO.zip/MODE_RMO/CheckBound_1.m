% Constrained Single-Objective Optimization Using Particle Swarm Optimization
% Karin Zielinski and Rainer Laur
% 2006 IEEE Congress on Evolutionary Computation
% Sheraton Vancouver Wall Centre Hotel, Vancouver, BC, Canada
% July 16-21, 2006

function C1=CheckBound_1(C,Cmax,Cmin,Cp)
%  ȷ��C��Խ��
[m,n]=size(C);

for i=1:m
    for j=1:n
        if C(i,j) >  Cmax(j)
            C1(i,j) = (Cmax(j)+Cp(j))/2;
        elseif C(i,j) < Cmin(j)
            C1(i,j) = (Cmin(j)+Cp(j))/2;
        else
             C1(i,j) = C(i,j);
        end
    end
end